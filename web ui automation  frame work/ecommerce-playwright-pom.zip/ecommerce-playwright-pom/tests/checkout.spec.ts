import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductPage } from '../pages/ProductPage';
import { CheckoutPage } from '../pages/CheckoutPage';

test('E-commerce End-to-End Checkout Flow', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const productPage = new ProductPage(page);
  const checkoutPage = new CheckoutPage(page);

  // 1. Login
  await loginPage.goto();
  await loginPage.login('standard_user', 'secret_sauce');

  // 2. Add Item to Cart & Open Cart
  await productPage.addBackpackToCart();
  await productPage.openCart();

  // 3. Complete Checkout Form
  await checkoutPage.completeCheckout('Nipun', 'Navodya', '11880');

  // 4. Verify Order Confirmation
  await expect(checkoutPage.successMessage).toHaveText('Thank you for your order!');
});
